[Build an Instagram clone with AngularJS, Satellizer, Node.js and MongoDB](https://hackhands.com/building-instagram-clone-angularjs-satellizer-nodejs-mongodb/)
=============================================================================================

![](https://lh6.googleusercontent.com/-TYJRMyl6254/VIiZa2KTbpI/AAAAAAAAEpc/DkwW_cX4OHI/w1982-h1290-no/Screenshot%2B2014-11-25%2B21.46.12.png)
